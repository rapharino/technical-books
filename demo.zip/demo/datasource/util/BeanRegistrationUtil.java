package com.example.demo.datasource.util;

import io.micrometer.core.instrument.util.StringUtils;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;

import java.util.Map;

public class BeanRegistrationUtil {

    public static boolean registerBeanDefinitionIfNotExists(BeanDefinitionRegistry registry, String beanName,
                                                            Class<?> beanClass) {
        if (registry.containsBeanDefinition(beanName)) {
            return false;
        }
        String[] candidates = registry.getBeanDefinitionNames();
        for (String candidate : candidates) {
            BeanDefinition beanDefinition = registry.getBeanDefinition(candidate);
            if (beanClass.getName().equals(beanDefinition.getBeanClassName())) {
                return false;
            }
        }
        BeanDefinition beanDefinition = BeanDefinitionBuilder.genericBeanDefinition(beanClass).getBeanDefinition();
        registry.registerBeanDefinition(beanName, beanDefinition);
        return true;
    }

    public static boolean registerBeanDefinitionIfNotExists(BeanDefinitionRegistry registry, String beanName,
                                                            Class<?> beanClass, String factoryMethod, String initMethodName, String destroyMethodName) {
        if (registry.containsBeanDefinition(beanName)) {
            return false;
        }
        String[] candidates = registry.getBeanDefinitionNames();
        for (String candidate : candidates) {
            BeanDefinition beanDefinition = registry.getBeanDefinition(candidate);
            if (beanClass.getName().equals(beanDefinition.getBeanClassName())) {
                return false;
            }
        }
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(beanClass);
        if (StringUtils.isNotBlank(factoryMethod)) {
            builder.setFactoryMethod(factoryMethod);
        }
        if (StringUtils.isNotBlank(initMethodName)) {
            builder.setInitMethodName(initMethodName);
        }
        if (StringUtils.isNotBlank(destroyMethodName)) {
            builder.setDestroyMethodName(destroyMethodName);
        }

        registry.registerBeanDefinition(beanName, builder.getBeanDefinition());
        return true;
    }

    public static boolean registerBeanDefinitionWithArgsIfNotExists(BeanDefinitionRegistry registry, String beanName,
                                                                    Class<?> beanClass, Object[] constructorArgs, Map<String, Object> properties) {
        return registerBeanDefinitionWithArgsIfNotExists(registry, beanName, beanClass, constructorArgs, properties, null, null);
    }

    public static boolean registerBeanDefinitionWithArgsIfNotExists(BeanDefinitionRegistry registry, String beanName,
                                                                    Class<?> beanClass, Object[] constructorArgs, Map<String, Object> properties, String destroyMethodName, String initialMethodName) {
        if (registry.containsBeanDefinition(beanName)) {
            return false;
        }
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(beanClass);
        if (constructorArgs != null) {
            for (Object arg : constructorArgs) {
                builder.addConstructorArgValue(arg);
            }
        }
        if (properties != null) {
            for (String propertyName : properties.keySet()) {
                builder.addPropertyValue(propertyName, properties.get(propertyName));
            }
        }
        if (destroyMethodName != null) {
            builder.setDestroyMethodName(destroyMethodName);
        }

        if (initialMethodName != null) {
            builder.setInitMethodName(initialMethodName);
        }
        registry.registerBeanDefinition(beanName, builder.getBeanDefinition());
        return true;
    }
}