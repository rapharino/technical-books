package com.example.demo.datasource;

import com.ctrip.framework.apollo.spring.annotation.EnableApolloConfig;
import com.google.inject.internal.cglib.core.$NamingPolicy;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.annotation.AliasFor;

import java.lang.annotation.*;

/**
 * Created By Rapharino on 2020/11/10 3:13 下午
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import(DataSourceRegister.class)
@Configuration
@EnableApolloConfig
public @interface ImportDataSource {
    // bean name
    /**
     * Exclude specific auto-configuration classes such that they will never be applied.
     * @return the classes to exclude
     */
    String name();
    // bind property prefix
    @AliasFor(annotation = EnableApolloConfig.class,attribute = "value")
    String propertiesPrefix();  // spring.shardingsphere[db_test]
}
