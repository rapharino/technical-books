package com.example.demo.datasource;

import com.example.demo.AbstractImportBeanDefinitionRegistrar;
import com.example.demo.datasource.util.BeanRegistrationUtil;
import com.example.demo.datasource.util.DatasourceUtil;
import com.example.demo.datasource.util.PropertiesBindUtil;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.shardingsphere.core.rule.ShardingRule;
import org.apache.shardingsphere.core.yaml.config.sharding.YamlShardingRuleConfiguration;
import org.apache.shardingsphere.core.yaml.swapper.ShardingRuleConfigurationYamlSwapper;
import org.apache.shardingsphere.shardingjdbc.jdbc.core.datasource.ShardingDataSource;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.core.annotation.AnnotationAttributes;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.util.Map;
import java.util.Properties;

/**
 * Created By Rapharino on 2020/11/10 3:14 下午
 */
@Slf4j
public class DataSourceRegister extends AbstractImportBeanDefinitionRegistrar<ImportDataSource> {

    @Override
    protected Class<ImportDataSource> getAnnotation() {
        return ImportDataSource.class;
    }

    @SneakyThrows
    @Override
    protected void doRegisterBeanDefinitions(ConfigurableEnvironment environment, BeanDefinitionRegistry registry, AnnotationAttributes annotationAttributes) {
        String beanName = annotationAttributes.getString("name");
        String propertiesPrefix = StringUtils.isEmpty(annotationAttributes.getString("propertiesPrefix"))?
                    "spring.shardingsphere["+beanName.trim()+"]":annotationAttributes.getString("propertiesPrefix");

        Assert.hasLength(beanName, "@ImportDataSource name must not be empty");
        Assert.hasLength(propertiesPrefix, "@ImportDataSource propertiesPrefix must not be empty");
        //datasource
        Map<String, DataSource> dataSourceMap = DatasourceUtil.createDataSource(environment, propertiesPrefix + ".datasource.");
        // rule
        YamlShardingRuleConfiguration rule = PropertiesBindUtil.bind(environment, propertiesPrefix + ".shard", YamlShardingRuleConfiguration.class);
        // properties
        Properties properties = PropertiesBindUtil.bind(environment, propertiesPrefix + ".properties", Properties.class);
        boolean result = BeanRegistrationUtil.registerBeanDefinitionWithArgsIfNotExists(
                registry,
                beanName,
                ShardingDataSource.class,
                new Object[]{
                        dataSourceMap,
                        new ShardingRule(new ShardingRuleConfigurationYamlSwapper().swap(rule), dataSourceMap.keySet()),
                        properties,
                },
                null,
                "close",
                null);
        if (!result) {
            Assert.isTrue(result, "import datasource[" + beanName + "] error");
        }
    }

}