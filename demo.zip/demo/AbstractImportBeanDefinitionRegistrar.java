package com.example.demo;

import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.annotation.AnnotationAttributes;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotationMetadata;

import java.lang.annotation.Annotation;

/**
 * Created By Rapharino on 2020/11/13 10:42 上午
 */
public abstract class AbstractImportBeanDefinitionRegistrar<T extends Annotation> implements ImportBeanDefinitionRegistrar, EnvironmentAware {

    private ConfigurableEnvironment environment;

    @Override
    public void setEnvironment(Environment environment) {
        this.environment = (ConfigurableEnvironment) environment;
    }

    protected abstract Class<T> getAnnotation();

    protected abstract void doRegisterBeanDefinitions(ConfigurableEnvironment environment, BeanDefinitionRegistry registry, AnnotationAttributes annotationAttributes);

    @Override
    public void registerBeanDefinitions(
            AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
        AnnotationAttributes annotationAttributes = AnnotationAttributes
                .fromMap(importingClassMetadata.getAnnotationAttributes(getAnnotation().getName()));
        doRegisterBeanDefinitions(environment, registry, annotationAttributes);
    }
}