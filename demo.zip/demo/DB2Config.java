package com.example.demo;

import com.example.demo.datasource.ImportDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;


/**
 * @program: game_api
 * @description:
 * @author: Dading
 * @create: 2019-04-12 14:14
 * @version: 1.0
 **/

@MapperScan(basePackages = "com.example.demo.dao", sqlSessionFactoryRef = "f2")
@ImportDataSource(
        propertiesPrefix = "spring.shardingsphere[db_pay]",
        name = "db_pay3"
)
public class DB2Config {

    @Bean
    public DataSourceTransactionManager tm2(@Qualifier(value = "db_pay3") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean
    public SqlSessionFactory f2(@Qualifier("db_pay3") DataSource dataSource)
            throws Exception {
        final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(dataSource);
        sessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver()
                .getResources("classpath*:mapper/*Mapper.xml"));
        return sessionFactory.getObject();
    }

}