package com.example.demo;

import com.example.demo.datasource.ImportDataSource;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
@ImportDataSource(name = "db_pay",propertiesPrefix = "spring.shardingsphere[db_pay]")
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }
}
