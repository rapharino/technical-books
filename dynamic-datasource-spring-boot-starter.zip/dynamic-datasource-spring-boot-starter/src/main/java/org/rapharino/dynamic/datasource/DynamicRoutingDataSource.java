package org.rapharino.dynamic.datasource;

import org.rapharino.dynamic.datasource.support.DynamicDataSourceContextHolder;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.util.Map;

/**
 * Created By Rapharino on 2020/11/13 10:42 上午
 */
public class DynamicRoutingDataSource extends AbstractRoutingDataSource {

    private final String primary;

    private final Map<String, DataSource> dataSourceMap;

    public DynamicRoutingDataSource(String primary, Map<String, DataSource> dataSourceMap) {
        this.primary = primary;
        this.dataSourceMap = dataSourceMap;
    }

    @Override
    public DataSource determineDataSource() {
        return getDataSource(DynamicDataSourceContextHolder.peek());
    }

    /**
     * 获取数据源
     *
     * @param ds 数据源名称
     * @return 数据源
     */
    public DataSource getDataSource(String ds) {
        if (StringUtils.isEmpty(ds)) {
            return dataSourceMap.get(primary);
        } else if (dataSourceMap.containsKey(ds)) {
            return dataSourceMap.get(ds);
        }
        return dataSourceMap.get(primary);
    }
}