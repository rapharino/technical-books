package org.rapharino.dynamic.datasource.annotation;

import java.lang.annotation.*;

/**
 * Created By Rapharino on 2020/11/13 10:42 上午
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface DS {
    /**
     * ds name
     *
     * @return
     */
    String value();
}