package com.baomidou.samples.mybatisplus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.samples.mybatisplus.entity.User;

public interface UserMapper extends BaseMapper<User> {
}
