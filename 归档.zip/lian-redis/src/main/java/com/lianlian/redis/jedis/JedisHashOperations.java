package com.lianlian.redis.jedis;

import com.lianlian.redis.core.HashOperations;
import com.lianlian.redis.util.JedisUtils;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created By Rapharino on 2020/9/2 9:52 上午
 */
public class JedisHashOperations extends AbstractOperations implements HashOperations {

    protected JedisHashOperations(JedisTemplate template) {
        super(template);
    }

    @Override
    public Long delete(String key, String... hashKeys) {
        return template.execute(jedis -> jedis.hdel(key, hashKeys));
    }

    @Override
    public Boolean hasKey(String key, String hashKey) {
        return template.execute(jedis -> jedis.hexists(key, hashKey));
    }

    @Override
    public String get(String key, String hashKey) {
        return template.execute(jedis -> jedis.hget(key, hashKey));
    }

    @Override
    public List<String> multiGet(String key, Collection<String> hashKeys) {
        return template.execute(jedis -> jedis.hmget(key, JedisUtils.toArrayOfKeyCollection(hashKeys)));
    }

    @Override
    public Long increment(String key, String hashKey, long delta) {
        return template.execute(jedis -> jedis.hincrBy(key, hashKey, delta));
    }

    @Override
    public Double increment(String key, String hashKey, double delta) {
        return template.execute(jedis -> jedis.hincrByFloat(key, hashKey, delta));
    }

    @Override
    public Set<String> keys(String key) {
        return template.execute(jedis -> jedis.hkeys(key));
    }

    @Override
    public Long size(String key) {
        return template.execute(jedis -> jedis.hlen(key));
    }

    @Override
    public void putAll(String key, Map<String, String> map) {
         template.execute(jedis -> jedis.hmset(key, map));
    }

    @Override
    public void put(String key, String hashKey, String value) {
         template.execute(jedis -> jedis.hset(key, hashKey, value));
    }

    @Override
    public Boolean putIfAbsent(String key, String hashKey, String value) {
        return template.execute(jedis ->  JedisUtils.toBoolean(jedis.hsetnx(key, hashKey, value)));
    }

    @Override
    public List<String> values(String key) {
        return template.execute(jedis -> jedis.hvals(key));
    }

    @Override
    public Map<String, String> entries(String key) {
        return template.execute(jedis -> jedis.hgetAll(key));
    }
}
