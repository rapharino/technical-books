package com.lianlian.redis.counter;

import com.lianlian.common.atomic.Counter;
import com.lianlian.redis.RedisTemplate;

/**
 * Created By Rapharino on 2020/9/7 4:43 下午
 */
public class RedisCounter implements Counter {

    private final RedisTemplate redisTemplate;
    // == key
    private final String namespace;
    // == hash key
    private final String key;

    public RedisCounter(RedisTemplate redisTemplate, String namespace, String key) {
        this.redisTemplate = redisTemplate;
        this.namespace = namespace;
        this.key = key;
    }

    @Override
    public Long get() throws Exception {
        return Long.valueOf(redisTemplate.opsForHash().get(namespace, key));
    }

    @Override
    public void set(Long newValue) throws Exception {
        redisTemplate.opsForHash().put(namespace, key, String.valueOf(newValue));
    }

    @Override
    public Long increment() throws Exception {
        return redisTemplate.opsForHash().increment(namespace, key, 1);
    }

    @Override
    public Long increment(Long delta) throws Exception {
        return redisTemplate.opsForHash().increment(namespace, key, delta);
    }

    @Override
    public Long decrement() throws Exception {
        return redisTemplate.opsForHash().increment(namespace, key, -1);
    }

    @Override
    public Long decrement(Long delta) throws Exception {
        return redisTemplate.opsForHash().increment(namespace, key, delta);
    }
}
