package com.lianlian.redis.jedis;

import com.lianlian.redis.core.ListOperations;
import com.lianlian.redis.util.JedisUtils;
import com.lianlian.redis.util.TimeoutUtils;
import redis.clients.jedis.BinaryClient;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created By Rapharino on 2020/9/2 9:59 上午
 */
public class JedisListOperations extends AbstractOperations implements ListOperations {

    protected JedisListOperations(JedisTemplate template) {
        super(template);
    }

    @Override
    public List<String> range(String key, long start, long end) {
        return template.execute(jedis -> jedis.lrange(key, start, end));
    }

    @Override
    public void trim(String key, long start, long end) {
        template.execute(jedis -> jedis.ltrim(key, start, end));
    }

    @Override
    public Long size(String key) {
        return template.execute(jedis -> jedis.llen(key));
    }

    @Override
    public Long leftPush(String key, String value) {
        return template.execute(jedis -> jedis.lpush(key, new String[]{value}));
    }

    @Override
    public Long leftPushAll(String key, String... values) {
        return template.execute(jedis -> jedis.lpush(key, values));
    }

    @Override
    public Long leftPushAll(String key, Collection<String> values) {
        return template.execute(jedis -> jedis.lpush(key, JedisUtils.toArrayOfValue(values)));
    }

    @Override
    public Long leftPushIfPresent(String key, String value) {
        return template.execute(jedis -> jedis.lpushx(key, new String[]{value}));
    }

    @Override
    public Long leftPush(String key, String pivot, String value) {
        return template.execute(jedis -> jedis.linsert(key, BinaryClient.LIST_POSITION.BEFORE, pivot, value));
    }

    @Override
    public Long rightPush(String key, String value) {
        return template.execute(jedis -> jedis.rpush(key, new String[]{value}));
    }

    @Override
    public Long rightPushAll(String key, String... values) {
        return template.execute(jedis -> jedis.rpush(key, values));
    }

    @Override
    public Long rightPushAll(String key, Collection<String> values) {
        return template.execute(jedis -> jedis.rpush(key, JedisUtils.toArrayOfValue(values)));
    }

    @Override
    public Long rightPushIfPresent(String key, String value) {
        return template.execute(jedis -> jedis.rpushx(key, new String[]{value}));
    }

    @Override
    public Long rightPush(String key, String pivot, String value) {
        return template.execute(jedis -> jedis.linsert(key, BinaryClient.LIST_POSITION.AFTER, pivot, value));
    }

    @Override
    public void set(String key, long index, String value) {
        template.execute(jedis -> jedis.lset(key, index, value));
    }

    @Override
    public Long remove(String key, long count, String value) {
        return template.execute(jedis -> jedis.lrem(key, count, value));
    }

    @Override
    public String index(String key, long index) {
        return template.execute(jedis -> jedis.lindex(key, index));
    }

    @Override
    public String leftPop(String key) {
        return template.execute(jedis -> jedis.lpop(key));
    }

    @Override
    public String leftPop(String key, long timeout, TimeUnit unit) {
        int second = (int) TimeoutUtils.toSeconds(timeout, unit);
        List<String> result = template.execute(jedis -> jedis.blpop(second, key));
        return (result == null || result.isEmpty()) ? null : result.get(1);
    }

    @Override
    public String rightPop(String key) {
        return template.execute(jedis -> jedis.rpop(key));
    }

    @Override
    public String rightPop(String key, long timeout, TimeUnit unit) {
        int second = (int) TimeoutUtils.toSeconds(timeout, unit);
        List<String> result = template.execute(jedis -> jedis.brpop(second, key));
        return (result == null || result.isEmpty()) ? null : result.get(1);
    }

    @Override
    public String rightPopAndLeftPush(String sourceKey, String destinationKey) {
        return template.execute(jedis -> jedis.rpoplpush(sourceKey, destinationKey));
    }

    @Override
    public String rightPopAndLeftPush(String sourceKey, String destinationKey, long timeout, TimeUnit unit) {
        int second = (int)TimeoutUtils.toSeconds(timeout, unit);
        return template.execute(jedis -> jedis.brpoplpush(sourceKey, destinationKey, second));
    }
}
