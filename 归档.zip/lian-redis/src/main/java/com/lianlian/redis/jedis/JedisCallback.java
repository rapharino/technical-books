package com.lianlian.redis.jedis;

import redis.clients.jedis.Jedis;

public interface JedisCallback<T> {

    T doInRedis(Jedis jedis);
}