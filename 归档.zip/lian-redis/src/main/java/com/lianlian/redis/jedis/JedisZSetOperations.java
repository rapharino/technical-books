package com.lianlian.redis.jedis;

import com.lianlian.redis.core.ZSetOperations;
import com.lianlian.redis.util.JedisUtils;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * Created By Rapharino on 2020/9/2 10:34 上午
 */
public class JedisZSetOperations extends AbstractOperations implements ZSetOperations {

    protected JedisZSetOperations(JedisTemplate template) {
        super(template);
    }

    @Override
    public Boolean add(String key, String value, double score) {
        return template.execute(jedis -> JedisUtils.toBoolean(jedis.zadd(key, score, value)));
    }

    @Override
    public Long add(String key, Map<String, Double> tuples) {
        return template.execute(jedis -> jedis.zadd(key, tuples));
    }

    @Override
    public Long remove(String key, String... values) {
        return template.execute(jedis -> jedis.zrem(key, values));
    }

    @Override
    public Double incrementScore(String key, String value, double delta) {
        return template.execute(jedis -> jedis.zincrby(key, delta, value));
    }

    @Override
    public Long rank(String key, String value) {
        return template.execute(jedis -> jedis.zrank(key, value));
    }

    @Override
    public Long reverseRank(String key, String value) {
        return template.execute(jedis -> jedis.zrevrank(key, value));
    }

    @Override
    public Set<String> range(String key, long start, long end) {
        return template.execute(jedis -> jedis.zrange(key, start, end));
    }

    @Override
    public Set<Tuple> rangeWithScores(String key, long start, long end) {
        return template.execute(jedis -> wrapper(jedis.zrangeWithScores(key, start, end)));
    }

    @Override
    public Set<String> rangeByScore(String key, double min, double max) {
        return template.execute(jedis -> jedis.zrangeByScore(key, min, max));
    }

    @Override
    public Set<Tuple> rangeByScoreWithScores(String key, double min, double max) {
        return template.execute(jedis -> wrapper(jedis.zrangeByScoreWithScores(key, min, max)));
    }

    @Override
    public Set<String> rangeByScore(String key, double min, double max, long offset, long count) {
        return template.execute(jedis -> jedis.zrangeByScore(key, min, max, (int) offset, (int) count));
    }

    @Override
    public Set<Tuple> rangeByScoreWithScores(String key, double min, double max, long offset, long count) {
        return template.execute(jedis -> wrapper(jedis.zrangeByScoreWithScores(key, min, max, (int) offset, (int) count)));
    }

    @Override
    public Set<String> reverseRange(String key, long start, long end) {
        return template.execute(jedis -> jedis.zrevrange(key, start, end));
    }

    @Override
    public Set<Tuple> reverseRangeWithScores(String key, long start, long end) {
        return template.execute(jedis -> wrapper(jedis.zrevrangeWithScores(key, start, end)));
    }

    @Override
    public Set<String> reverseRangeByScore(String key, double min, double max) {
        return template.execute(jedis -> jedis.zrevrangeByScore(key, max, min));
    }

    @Override
    public Set<Tuple> reverseRangeByScoreWithScores(String key, double min, double max) {
        return template.execute(jedis -> wrapper(jedis.zrevrangeByScoreWithScores(key, max, min)));
    }

    @Override
    public Set<String> reverseRangeByScore(String key, double min, double max, long offset, long count) {
        return template.execute(jedis -> jedis.zrevrangeByScore(key, max, min, (int) offset, (int) count));
    }

    @Override
    public Set<Tuple> reverseRangeByScoreWithScores(String key, double min, double max, long offset, long count) {
        return template.execute(jedis -> wrapper(jedis.zrevrangeByScoreWithScores(key, max, min, (int) offset, (int) count)));
    }

    @Override
    public Long count(String key, double min, double max) {
        return template.execute(jedis -> jedis.zcount(key, min, max));
    }

    @Override
    public Long size(String key) {
        return this.zCard(key);
    }

    @Override
    public Long zCard(String key) {
        return template.execute(jedis -> jedis.zcard(key));
    }

    @Override
    public Double score(String key, String value) {
        return template.execute(jedis -> jedis.zscore(key, value));
    }

    @Override
    public Long removeRange(String key, long start, long end) {
        return template.execute(jedis -> jedis.zremrangeByRank(key, start, end));
    }

    @Override
    public Long removeRangeByScore(String key, double min, double max) {
        return template.execute(jedis -> jedis.zremrangeByScore(key, min, max));
    }

    @Override
    public Long unionAndStore(String key, String otherKey, String destKey) {
        return template.execute(jedis -> jedis.zunionstore(destKey, new String[]{key, otherKey}));
    }

    @Override
    public Long unionAndStore(String key, Collection<String> otherKeys, String destKey) {
        return template.execute(jedis -> jedis.zunionstore(destKey, JedisUtils.toArrayOfKeyCollection(otherKeys)));
    }

    @Override
    public Long intersectAndStore(String key, String otherKey, String destKey) {
        return template.execute(jedis -> jedis.zinterstore(destKey, new String[]{key, otherKey}));
    }

    @Override
    public Long intersectAndStore(String key, Collection<String> otherKeys, String destKey) {
        return template.execute(jedis -> jedis.zinterstore(destKey, JedisUtils.toArrayOfKeyCollection(otherKeys)));
    }

    Set<Tuple> wrapper(Collection<redis.clients.jedis.Tuple> rawValues) {
        if (rawValues == null) {
            return null;
        }
        Set<Tuple> set = new LinkedHashSet<>(rawValues.size());
        for (redis.clients.jedis.Tuple rawValue : rawValues) {
            set.add(new DefaultTuple(rawValue.getElement(), rawValue.getScore()));
        }
        return set;
    }

    class DefaultTuple implements Tuple {

        private final Double score;
        private final String value;

        /**
         * Constructs a new <code>DefaultTypedTuple</code> instance.
         *
         * @param value
         * @param score
         */
        public DefaultTuple(String value, Double score) {
            this.score = score;
            this.value = value;
        }

        public Double getScore() {
            return score;
        }

        public String getValue() {
            return value;
        }

        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((score == null) ? 0 : score.hashCode());
            result = prime * result + ((value == null) ? 0 : value.hashCode());
            return result;
        }

        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (!(obj instanceof DefaultTuple))
                return false;
            DefaultTuple other = (DefaultTuple) obj;
            if (score == null) {
                if (other.score != null)
                    return false;
            } else if (!score.equals(other.score))
                return false;
            if (value == null) {
                if (other.value != null)
                    return false;
            } else if (!value.equals(other.value))
                return false;
            return true;
        }

        public int compareTo(Double o) {

            double thisScore = (score == null ? 0.0 : score);
            double otherScore = (o == null ? 0.0 : o);

            return Double.compare(thisScore, otherScore);
        }

        @Override
        public int compareTo(Tuple o) {

            if (o == null) {
                return compareTo(Double.valueOf(0));
            }

            return compareTo(o.getScore());
        }
    }
}
