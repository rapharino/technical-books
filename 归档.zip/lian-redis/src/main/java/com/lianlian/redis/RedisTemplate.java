package com.lianlian.redis;

import com.lianlian.redis.core.*;

/**
 * Created By Rapharino on 2020/9/1 1:51 下午
 */
public interface RedisTemplate extends RedisOperations {

    /**
     * ops for hash
     *
     * @return
     */
    HashOperations opsForHash();

    /**
     * ops for list
     *
     * @return
     */
    StringOperations opsForString();

    /**
     * ops for list
     *
     * @return
     */
    ListOperations opsForList();

    /**
     * ops for set
     *
     * @return
     */
    SetOperations opsForSet();

    /**
     * ops for zset
     *
     * @return
     */
    ZSetOperations opsForZSet();

}
