package com.lianlian.redis.core;

import java.util.Collection;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Created By Rapharino on 2020/9/1 9:37 上午
 * <p>
 * Interface that specified a [basic] set of Redis operations
 */
public interface RedisOperations {
    /**
     * Determine if given {@code key} exists.
     *
     * @param key must not be {@literal null}.
     * @return
     * @see <a href="http://redis.io/commands/exists">Redis Documentation: EXISTS</a>
     */
    Boolean hasKey(String key);

    /**
     * Delete given {@code key}.
     *
     * @param key must not be {@literal null}.
     * @return The number of keys that were removed.
     * @see <a href="http://redis.io/commands/del">Redis Documentation: DEL</a>
     */
    void delete(String key);

    /**
     * Delete given {@code keys}.
     *
     * @param keys must not be {@literal null}.
     * @return The number of keys that were removed.
     * @see <a href="http://redis.io/commands/del">Redis Documentation: DEL</a>
     */
    void delete(Collection<String> keys);


    /**
     * Rename key {@code oldKey} to {@code newKey}.
     *
     * @param oldKey must not be {@literal null}.
     * @param newKey must not be {@literal null}.
     * @see <a href="http://redis.io/commands/rename">Redis Documentation: RENAME</a>
     */
    void rename(String oldKey, String newKey);

    /**
     * Rename key {@code oleName} to {@code newKey} only if {@code newKey} does not exist.
     *
     * @param oldKey must not be {@literal null}.
     * @param newKey must not be {@literal null}.
     * @return
     * @see <a href="http://redis.io/commands/renamenx">Redis Documentation: RENAMENX</a>
     */
    Boolean renameIfAbsent(String oldKey, String newKey);

    /**
     * Set time to live for given {@code key}..
     *
     * @param key     must not be {@literal null}.
     * @param timeout
     * @param unit    must not be {@literal null}.
     * @return
     */
    void expire(String key, long timeout, TimeUnit unit);

    /**
     * Set the expiration for given {@code key} as a {@literal date} timestamp.
     *
     * @param key  must not be {@literal null}.
     * @param date must not be {@literal null}.
     * @return
     */
    void expireAt(String key, Date date);

    /**
     * Remove the expiration from given {@code key}.
     *
     * @param key must not be {@literal null}.
     * @return
     * @see <a href="http://redis.io/commands/persist">Redis Documentation: PERSIST</a>
     */
    Boolean persist(String key);

    /**
     * Get the time to live for {@code key} in seconds.
     *
     * @param key must not be {@literal null}.
     * @return
     * @see <a href="http://redis.io/commands/ttl">Redis Documentation: TTL</a>
     */
    Long getExpire(String key);
}
