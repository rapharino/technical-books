package com.lianlian.redis.exception;

/**
 * Created By Rapharino on 2020/9/1 9:26 上午
 *
 * redis connection exception
 * <p>
 */
public class RedisConnectionException extends RedisException {

    public RedisConnectionException(String message) {
        super(message);
    }

    public RedisConnectionException(String message, Throwable cause) {
        super(message, cause);
    }
}
