//package com.lianlian.redis.counter;
//
//import com.lianlian.core.atomic.CachedCounterFactory;
//import com.lianlian.core.atomic.Counter;
//import com.lianlian.redis.RedisTemplate;
//
///**
// * Created By Rapharino on 2020/9/7 7:50 下午
// */
//public class RedisCounterFactory extends CachedCounterFactory {
//
//    private final RedisTemplate redisTemplate;
//
//    public RedisCounterFactory(RedisTemplate redisTemplate) {
//        this.redisTemplate = redisTemplate;
//    }
//
//    @Override
//    protected Counter create(String namespace, String key) {
//        return new RedisCounter(this.redisTemplate, namespace, key);
//    }
//}
