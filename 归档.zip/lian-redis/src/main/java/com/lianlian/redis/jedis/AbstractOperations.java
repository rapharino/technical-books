package com.lianlian.redis.jedis;

/**
 * Created By Rapharino on 2020/9/2 9:34 上午
 */
public abstract class AbstractOperations {

    protected final JedisTemplate template;

    protected AbstractOperations(JedisTemplate template) {
        this.template = template;
    }
}
