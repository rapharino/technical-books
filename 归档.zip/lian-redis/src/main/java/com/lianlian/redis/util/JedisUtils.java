package com.lianlian.redis.util;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;

public class JedisUtils {

    public JedisUtils() {
    }

    public static Boolean toBoolean(Long result) {
        return result != null ? result == 1L : null;
    }

    public static Boolean isOk(String result) {
        return "OK".equals(result);
    }

    public static String[] toArrayOfMap(Map<String, String> map, Function<String, String> keyMapFunc) {
        if (map != null && map.size() != 0) {
            String[] result = new String[map.size() * 2];
            int index = 0;

            Entry entry;
            for (Iterator var4 = map.entrySet().iterator(); var4.hasNext(); result[index++] = (String) entry.getValue()) {
                entry = (Entry) var4.next();
                result[index++] = keyMapFunc.apply((String) entry.getKey());
            }

            return result;
        } else {
            return null;
        }
    }

    public static String[] toArrayOfMap(Map<String, String> map) {
        return toArrayOfMap(map, (key) -> {
            return key;
        });
    }

    public static String[] toArrayOfKeyCollection(Collection<String> keys, Function<String, String> keyMapFunction) {
        if (keys == null || keys.isEmpty()) {
            return null;
        } else {
            String[] result = new String[keys.size()];
            int index = 0;

            String key;
            for (Iterator var4 = keys.iterator(); var4.hasNext(); result[index++] = (String) keyMapFunction.apply(key)) {
                key = (String) var4.next();
            }

            return result;
        }
    }

    public static String[] toArrayOfKeyCollection(Collection<String> keys) {
        return toArrayOfKeyCollection(keys, (key) -> {
            return key;
        });
    }

    public static String[] toArrayOfValue(Collection<String> values) {
        if (values == null || values.isEmpty()) {
            return null;
        } else {
            String[] result = new String[values.size()];
            int index = 0;

            String value;
            for (Iterator var3 = values.iterator(); var3.hasNext(); result[index++] = value) {
                value = (String) var3.next();
            }

            return result;
        }
    }
}
