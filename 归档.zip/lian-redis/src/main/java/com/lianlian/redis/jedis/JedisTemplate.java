package com.lianlian.redis.jedis;

import com.lianlian.redis.RedisProperties;
import com.lianlian.redis.RedisTemplate;
import com.lianlian.redis.core.*;
import com.lianlian.redis.exception.RedisConnectionException;
import com.lianlian.redis.exception.RedisException;
import com.lianlian.redis.util.JedisUtils;
import com.lianlian.redis.util.TimeoutUtils;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisSentinelPool;
import redis.clients.jedis.exceptions.JedisConnectionException;
import redis.clients.jedis.exceptions.JedisDataException;
import redis.clients.jedis.exceptions.JedisException;
import redis.clients.util.Pool;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * Created By Rapharino on 2020/9/1 1:51 下午
 */
public class JedisTemplate implements RedisTemplate, InitializingBean, DisposableBean {

    private StringOperations stringOperations;
    private HashOperations hashOperations;
    private ListOperations listOperations;
    private SetOperations setOperations;
    private ZSetOperations zSetOperations;
    private Pool<Jedis> jedisPool; // sentinel or cluster

    private final RedisProperties config;

    public JedisTemplate(RedisProperties config) {
        this.config = config;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(this.config, "RedisProperties is required");
        // todo :  not only sentinel[mode] but also cluster[mode]
        this.jedisPool = newRedisSentinelPool(config);
    }

    @Override
    public void destroy() throws Exception {
        if (this.jedisPool != null) {
            this.jedisPool.close();
        }
    }

    public <T> T execute(JedisCallback<T> callback) {
        Jedis jedis = null;
        T result;
        try {
            jedis = this.jedisPool.getResource();
            result = callback.doInRedis(jedis);
        } catch (Exception exception) {
            throw newRedisException(exception);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return (T) result;
    }

    /**
     * Creates {@link JedisSentinelPool}.
     *
     * @param config
     * @return
     * @since 1.4
     */
    private Pool<Jedis> newRedisSentinelPool(RedisProperties config) {
        return new JedisSentinelPool(config.getSentinel().getMaster(), StringUtils.commaDelimitedListToSet(config.getSentinel().getNodes()),
                getPoolConfig(), config.getTimeout(),
                config.getPassword(), config.getDatabase());
    }

    private JedisPoolConfig getPoolConfig() {
        JedisPoolConfig poolConfig = new JedisPoolConfig();
        poolConfig.setMaxTotal(config.getPool().getMaxActive());
        poolConfig.setMaxIdle(config.getPool().getMaxIdle());
        poolConfig.setMinIdle(config.getPool().getMinIdle());
        poolConfig.setMaxWaitMillis(config.getPool().getMaxWait());
        poolConfig.setTestOnBorrow(Boolean.FALSE);
        poolConfig.setTestWhileIdle(Boolean.TRUE);
        return poolConfig;
    }

    @Override
    public Boolean hasKey(String key) {
        return execute(jedis -> jedis.exists(key));
    }

    @Override
    public void delete(String key) {
        execute(jedis -> jedis.del(key));
    }

    @Override
    public void delete(Collection<String> keys) {
        execute(jedis -> jedis.del(JedisUtils.toArrayOfKeyCollection(keys)));
    }

    @Override
    public void rename(String oldKey, String newKey) {
        execute(jedis -> jedis.rename(oldKey, newKey));
    }

    @Override
    public Boolean renameIfAbsent(String oldKey, String newKey) {
        return execute(jedis -> JedisUtils.toBoolean(jedis.renamenx(oldKey, newKey)));
    }

    @Override
    public void expire(String key, long timeout, TimeUnit unit) {
        long timeoutMillis = TimeoutUtils.toMillis(timeout, unit);
        execute(jedis -> jedis.pexpire(key, timeoutMillis));
    }

    @Override
    public void expireAt(String key, Date date) {
        execute(jedis -> jedis.pexpireAt(key, date.getTime()));
    }

    @Override
    public Boolean persist(String key) {
        return execute(jedis -> JedisUtils.toBoolean(jedis.persist(key)));
    }

    @Override
    public Long getExpire(String key) {
        return execute(jedis -> jedis.ttl(key));
    }

    @Override
    public HashOperations opsForHash() {
        if (hashOperations == null) {
            hashOperations = new JedisHashOperations(this);
        }
        return hashOperations;
    }

    @Override
    public StringOperations opsForString() {
        if (stringOperations == null) {
            stringOperations = new JedisStringOperations(this);
        }
        return stringOperations;
    }

    @Override
    public ListOperations opsForList() {
        if (listOperations == null) {
            listOperations = new JedisListOperations(this);
        }
        return listOperations;
    }

    @Override
    public SetOperations opsForSet() {
        if (setOperations == null) {
            setOperations = new JedisSetOperations(this);
        }
        return setOperations;
    }

    @Override
    public ZSetOperations opsForZSet() {
        if (zSetOperations == null) {
            zSetOperations = new JedisZSetOperations(this);
        }
        return zSetOperations;
    }

    public RedisException newRedisException(Exception ex) {

        if (ex instanceof RedisException) {
            return (RedisException) ex;
        }
        // redis io exception
        if (ex instanceof JedisConnectionException) {
            return new RedisConnectionException(ex.getMessage(), ex);
        }
        // redis server dara error
        if (ex instanceof JedisDataException) {
            return new RedisConnectionException(ex.getMessage(), ex);
        }
        //  other  JedisException
        if (ex instanceof JedisException) {
            return new RedisConnectionException(ex.getMessage(), ex);
        }
        // unknown host
        if (ex instanceof UnknownHostException) {
            return new RedisConnectionException("Unknown host " + ex.getMessage(), ex);
        }
        // unknown io
        if (ex instanceof IOException) {
            return new RedisConnectionException("Could not connect to Redis server", ex);
        }

        return new RedisException(ex.getMessage(), ex);
    }

}
