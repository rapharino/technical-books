package com.lianlian.redis.jedis;

import com.lianlian.redis.core.SetOperations;
import com.lianlian.redis.util.JedisUtils;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created By Rapharino on 2020/9/2 10:20 上午
 */
public class JedisSetOperations extends AbstractOperations implements SetOperations {


    protected JedisSetOperations(JedisTemplate template) {
        super(template);
    }

    @Override
    public Long add(String key, String... values) {
        return template.execute(jedis -> jedis.sadd(key, values));
    }

    @Override
    public Long remove(String key, String... values) {
        return template.execute(jedis -> jedis.srem(key, values));
    }

    @Override
    public String pop(String key) {
        return template.execute(jedis -> jedis.spop(key));
    }

    @Override
    public Boolean move(String key, String value, String destKey) {
        return template.execute(jedis -> JedisUtils.toBoolean(jedis.smove(key, destKey, value)));
    }

    @Override
    public Long size(String key) {
        return template.execute(jedis -> jedis.scard(key));
    }

    @Override
    public Boolean isMember(String key, String value) {
        return template.execute(jedis -> jedis.sismember(key, value));
    }

    @Override
    public Set<String> intersect(String key, String otherKey) {
        return template.execute(jedis -> jedis.sinter(new String[]{key, otherKey}));
    }

    @Override
    public Set<String> intersect(String key, Collection<String> otherKeys) {
        otherKeys.add(key);
        String[] other =JedisUtils.toArrayOfKeyCollection(otherKeys);
        return template.execute(jedis -> jedis.sinter(other));
    }

    @Override
    public Long intersectAndStore(String key, String otherKey, String destKey) {
        return template.execute(jedis -> jedis.sinterstore(destKey, new String[]{key, otherKey}));
    }

    @Override
    public Long intersectAndStore(String key, Collection<String> otherKeys, String destKey) {
        return template.execute(jedis -> jedis.sinterstore(destKey, JedisUtils.toArrayOfKeyCollection(otherKeys)));
    }

    @Override
    public Set<String> union(String key, String otherKey) {
        return template.execute(jedis -> jedis.sunion(new String[]{key, otherKey}));
    }

    @Override
    public Set<String> union(String key, Collection<String> otherKeys) {
        return template.execute(jedis -> jedis.sunion(JedisUtils.toArrayOfKeyCollection(otherKeys)));
    }

    @Override
    public Long unionAndStore(String key, String otherKey, String destKey) {
        return template.execute(jedis -> jedis.sunionstore(destKey, new String[]{key, otherKey}));
    }

    @Override
    public Long unionAndStore(String key, Collection<String> otherKeys, String destKey) {
        return template.execute(jedis -> jedis.sunionstore(destKey, JedisUtils.toArrayOfKeyCollection(otherKeys)));
    }

    @Override
    public Set<String> difference(String key, String otherKey) {
        return template.execute(jedis -> jedis.sdiff(new String[]{key, otherKey}));
    }

    @Override
    public Set<String> difference(String key, Collection<String> otherKeys) {
        return template.execute(jedis -> jedis.sdiff(JedisUtils.toArrayOfKeyCollection(otherKeys)));
    }

    @Override
    public Long differenceAndStore(String key, String otherKey, String destKey) {
        return template.execute(jedis -> jedis.sdiffstore(destKey, new String[]{key, otherKey}));
    }

    @Override
    public Long differenceAndStore(String key, Collection<String> otherKeys, String destKey) {
        return template.execute(jedis -> jedis.sdiffstore(destKey, JedisUtils.toArrayOfKeyCollection(otherKeys)));
    }

    @Override
    public Set<String> members(String key) {
        return template.execute(jedis -> jedis.smembers(key));
    }

    @Override
    public String randomMember(String key) {
        return template.execute(jedis -> jedis.srandmember(key));
    }

    @Override
    public Set<String> distinctRandomMembers(String key, long count) {
        return template.execute(jedis -> new HashSet(jedis.srandmember(key, (int)count)));
    }

    @Override
    public List<String> randomMembers(String key, long count) {
        return template.execute(jedis -> jedis.srandmember(key, -((int)count)));
    }
}
