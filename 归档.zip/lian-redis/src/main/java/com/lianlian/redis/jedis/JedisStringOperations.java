package com.lianlian.redis.jedis;

import com.lianlian.redis.core.StringOperations;
import com.lianlian.redis.util.JedisUtils;
import com.lianlian.redis.util.TimeoutUtils;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created By Rapharino on 2020/9/1 10:04 上午
 */
public class JedisStringOperations extends AbstractOperations implements StringOperations {

    protected JedisStringOperations(JedisTemplate template) {
        super(template);
    }

    @Override
    public void set(String key, String value) {
        template.execute(jedis -> jedis.set(key, value));
    }

    @Override
    public void set(String key, String value, long timeout, TimeUnit unit) {
        int second = (int) TimeoutUtils.toSeconds(timeout, unit);
        template.execute(jedis -> jedis.setex(key, second, value));
    }

    @Override
    public Boolean setIfAbsent(String key, String value) {
        return template.execute(jedis -> JedisUtils.toBoolean(jedis.setnx(key, value)));
    }

    @Override
    public void multiSet(Map<String,String> map) {
        template.execute(jedis -> jedis.mset(JedisUtils.toArrayOfMap(map)));
    }

    @Override
    public Boolean multiSetIfAbsent(Map<String,String> map) {
        return template.execute(jedis -> JedisUtils.toBoolean(jedis.msetnx(JedisUtils.toArrayOfMap(map))));
    }

    @Override
    public String get(String key) {
        return template.execute(jedis -> jedis.get(key));
    }

    @Override
    public String getAndSet(String key, String value) {
        return template.execute(jedis -> jedis.getSet(key,value));
    }

    @Override
    public List<String> multiGet(Collection<String> keys) {
        return template.execute(jedis -> jedis.mget(JedisUtils.toArrayOfKeyCollection(keys)));
    }

    @Override
    public Long increment(String key, long delta) {
        return template.execute(jedis -> jedis.incrBy(key, delta));
    }

    @Override
    public Double increment(String key, double delta) {
        return template.execute(jedis -> jedis.incrByFloat(key, delta));
    }

    @Override
    public Long append(String key, String value) {
        return template.execute(jedis -> jedis.append(key, value));
    }

    @Override
    public String get(String key, long start, long end) {
        return template.execute(jedis -> jedis.getrange(key, start, end));
    }

    @Override
    public void set(String key, String value, long offset) {
         template.execute(jedis -> jedis.setrange(key, offset, value));
    }

    @Override
    public Long size(String key) {
        return template.execute(jedis -> jedis.strlen(key));
    }
}
