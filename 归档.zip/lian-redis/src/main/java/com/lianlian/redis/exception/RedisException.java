package com.lianlian.redis.exception;

/**
 * Created By Rapharino on 2020/9/1 9:26 上午
 *
 * redis connection exception
 * <p>
 */
public class RedisException extends RuntimeException {

    public RedisException(String message) {
        super(message);
    }

    public RedisException(String message, Throwable cause) {
        super(message, cause);
    }
}
