package com.lianlian.redis.jedis;

import com.lianlian.redis.RedisProperties;
import com.lianlian.redis.counter.RedisCounterFactory;

import java.time.LocalDateTime;
import java.util.Random;
import java.util.concurrent.*;

public class JedisTemplateTest {

    @org.junit.Test
    public void execute() throws Exception {
        RedisProperties properties = new RedisProperties();
        RedisProperties.Sentinel sentinel = new RedisProperties.Sentinel();
        sentinel.setMaster("mymaster");
        sentinel.setNodes("192.168.43.154:26379");
        properties.setSentinel(sentinel);
        properties.setPool(new RedisProperties.Pool());
        JedisTemplate template = new JedisTemplate(properties);
        template.afterPropertiesSet();
        for (;;){
            try {
                template.opsForString().set("11", LocalDateTime.now().toString());
            }catch (Throwable throwable){
                System.out.println("Error"+ LocalDateTime.now().toString());
            }
            Thread.sleep(1000);
        }
    }

    @org.junit.Test
    public void create() throws Exception {
        RedisProperties properties = new RedisProperties();
        RedisProperties.Sentinel sentinel = new RedisProperties.Sentinel();
        sentinel.setMaster("mymaster");
        sentinel.setNodes("192.168.43.154:26379");
        properties.setSentinel(sentinel);
        properties.setPool(new RedisProperties.Pool());
        JedisTemplate template = new JedisTemplate(properties);
        template.afterPropertiesSet();

        RedisCounterFactory counterFactory = new RedisCounterFactory(template);

        ExecutorService service = Executors.newFixedThreadPool(10);
        int count = 1000;
        CountDownLatch countDownLatch = new CountDownLatch(count);
        long s =System.currentTimeMillis();
        for (int i = 0; i < count; ++i) {
            service.submit(() -> {
                try {
                    counterFactory.counter("foo","key1").increment();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    countDownLatch.countDown();
                }
            });
        }
        countDownLatch.await();

        System.out.println(counterFactory.counter("foo","key1").get()+"--"+(System.currentTimeMillis()-s));
    }

    public static void main(String[] args) throws InterruptedException, ExecutionException {

        ExecutorService executor = Executors.newFixedThreadPool(10);

        for (;;){
            Future future =  executor.submit(new Runnable() {
                @Override
                public void run() {
                   // System.out.println("start");
                }
            }, "RRRR");
            System.out.println(future.get());
        }
    }

}