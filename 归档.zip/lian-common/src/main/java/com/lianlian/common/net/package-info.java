/**
 * 网络相关工具
 * 
 * @author looly
 *
 */
package com.lianlian.common.net;