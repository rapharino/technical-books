package com.lianlian.common.atomic;

/**
 * Created By Rapharino on 2020/9/8 11:11 上午
 */
public class AtomicValue {
    // current atomic value
    private boolean currentValue;
}
