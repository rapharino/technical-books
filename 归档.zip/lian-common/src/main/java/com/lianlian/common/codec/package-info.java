/**
 * BaseN以及BCD编码封装
 * 
 * @author looly
 *
 */
package com.lianlian.common.codec;