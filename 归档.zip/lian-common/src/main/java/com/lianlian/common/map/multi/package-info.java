/**
 * 列表类型值的Map实现
 * 
 * @author looly
 *
 */
package com.lianlian.common.map.multi;