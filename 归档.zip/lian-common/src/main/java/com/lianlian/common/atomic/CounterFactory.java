package com.lianlian.common.atomic;

/**
 * Created By Rapharino on 2020/9/7 7:47 下午
 */
public interface CounterFactory {
    /**
     * get / creat a counter
     *
     * @param namespace
     * @param key
     * @return
     */
    Counter counter(String namespace, String key);
}
