/**
 * 克隆封装
 * 
 * @author looly
 *
 */
package com.lianlian.common.clone;