package com.lianlian.common.atomic;

/**
 * Created By Rapharino on 2020/9/7 4:22 下午
 */
public interface Counter {

    /**
     * Gets the current value.
     *
     * @return the current value
     */
    Long get() throws Exception;

    /**
     * Sets to the given value.
     *
     * @param newValue the new value
     */
    void set(Long newValue) throws Exception;

    /**
     * Atomically increments by one the current value.
     *
     * @return the previous value
     */
    Long increment() throws Exception;

    /**
     * Atomically decrements by the given value.
     * @param delta the value to increment
     * @return the previous value
     */
    Long increment(Long delta) throws Exception;

    /**
     * Atomically decrements by one the current value.
     *
     * @return the previous value
     */
    Long decrement() throws Exception;

    /**
     * Atomically decrements by the given value.
     * @param delta the value to decrement
     * @return the previous value
     */
    Long decrement(Long delta) throws Exception;
}
