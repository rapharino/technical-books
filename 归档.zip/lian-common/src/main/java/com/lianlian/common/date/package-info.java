/**
 * 日期封装，日期的核心为DateTime类，DateUtil提供日期操作的入口
 * 
 * @author looly
 *
 */
package com.lianlian.common.date;