package com.lianlian.common.atomic;

import com.lianlian.common.lang.Assert;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Created By Rapharino on 2020/9/7 7:50 下午
 * cached counter factory
 */
public abstract class CachedCounterFactory implements CounterFactory {

    private ConcurrentHashMap<String, Counter> cached = new ConcurrentHashMap<>();

    private final static String SEPARATOR = "_NS/N_";

    @Override
    public Counter counter(String namespace, String name) {
        Assert.notBlank(namespace);
        Assert.notBlank(name);
        return cached.computeIfAbsent(namespace + SEPARATOR + name, n -> CachedCounterFactory.this.create(namespace,name));
    }

    protected abstract Counter create(String namespace,String key);
}
