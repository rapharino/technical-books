/**
 * getXXX方法的接口和抽象实现
 * 
 * @author looly
 *
 */
package com.lianlian.common.getter;