/**
 * Map相关封装，提供特殊Map实现以及Map工具MapUtil
 * 
 * @author looly
 *
 */
package com.lianlian.common.map;