/**
 * 各种比较器（Comparator）实现和封装
 * 
 * @author looly
 *
 */
package com.lianlian.common.comparator;