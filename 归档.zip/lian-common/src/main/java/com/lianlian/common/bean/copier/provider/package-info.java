/**
 * Bean值提供者方式封装
 * 
 * @author looly
 *
 */
package com.lianlian.common.bean.copier.provider;