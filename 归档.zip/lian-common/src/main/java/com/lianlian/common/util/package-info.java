/**
 * 提供各种工具方法，按照归类入口为XXXUtil，如字符串工具StrUtil等
 * 
 * @author looly
 *
 */
package com.lianlian.common.util;