/**
 * 锁的实现
 * 
 * @author looly
 *
 */
package com.lianlian.common.thread.lock;