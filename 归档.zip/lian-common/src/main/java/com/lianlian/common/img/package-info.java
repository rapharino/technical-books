/**
 * 图像处理相关工具类封装
 * 
 * @author looly
 *
 */
package com.lianlian.common.img;