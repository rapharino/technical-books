/**
 * 
 * ThreadLocal相关封装
 * @author looly
 *
 */
package com.lianlian.common.thread.threadlocal;