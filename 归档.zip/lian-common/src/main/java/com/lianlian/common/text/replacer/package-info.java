/**
 * 文本替换类抽象及实现
 * 
 * @author looly
 *
 */
package com.lianlian.common.text.replacer;