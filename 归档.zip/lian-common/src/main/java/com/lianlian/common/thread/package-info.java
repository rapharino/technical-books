/**
 * 提供线程及高并发封装，入口为ThreadUtil
 * 
 * @author looly
 *
 */
package com.lianlian.common.thread;