package com.lianlian.zookeeper.counter;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ZookeeperCounterFactoryTest {

    @org.junit.Test
    public void create() throws Exception {
        ZookeeperCounterFactory counterFactory = new ZookeeperCounterFactory("127.0.0.1:32771");
        counterFactory.afterPropertiesSet();
        counterFactory.counter("foo","key1").set(0L);
        ExecutorService service = Executors.newFixedThreadPool(1);
        int count = 5000;
        CountDownLatch countDownLatch = new CountDownLatch(count);
        long s =System.currentTimeMillis();
        for (int i = 0; i < count; ++i) {
            service.submit(() -> {
                try {
                    counterFactory.counter("foo","key1").increment();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    countDownLatch.countDown();
                }
            });
        }
        countDownLatch.await();

        System.out.println(counterFactory.counter("foo","key1").get()+"--"+(System.currentTimeMillis()-s));
    }
}