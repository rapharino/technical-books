package com.lianlian.zookeeper.counter;

import com.lianlian.common.atomic.Counter;
import org.apache.curator.framework.recipes.atomic.AtomicValue;
import org.apache.curator.framework.recipes.atomic.DistributedAtomicLong;

/**
 * Created By Rapharino on 2020/9/7 4:43 下午
 */
public class ZookeeperCounter implements Counter {

    private final DistributedAtomicLong zkCounter;

    public ZookeeperCounter(DistributedAtomicLong zkCounter) {
        this.zkCounter = zkCounter;
    }

    private <T> T postValue(AtomicValue<T> value) throws Exception {
        if (value.succeeded() == false) {
            throw new RuntimeException(" the operation failed and the distributed counter was not updated:"
                    + "OptimisticTries[" + value.getStats().getOptimisticTries() + "],"
                    + "OptimisticTimeMs[" + value.getStats().getOptimisticTimeMs() + "],"
                    + "PromotedLockTries[" + value.getStats().getPromotedLockTries() + "],"
                    + "OptimisticTimeMs[" + value.getStats().getOptimisticTimeMs() + "]"
            );
        }
        return value.postValue();
    }

    @Override
    public Long get() throws Exception {
        AtomicValue<Long> v = zkCounter.get();
        return postValue(v);
    }

    @Override
    public void set(Long newValue) throws Exception {
        zkCounter.forceSet(newValue);
    }

    @Override
    public Long increment() throws Exception {
        AtomicValue<Long> v = zkCounter.increment();
        return postValue(v);
    }

    @Override
    public Long increment(Long delta) throws Exception {
        AtomicValue<Long> v = zkCounter.add(delta);
        return postValue(v);
    }

    @Override
    public Long decrement() throws Exception {
        AtomicValue<Long> v = zkCounter.decrement();
        return postValue(v);
    }

    @Override
    public Long decrement(Long delta) throws Exception {
        AtomicValue<Long> v = zkCounter.subtract(delta);
        return postValue(v);
    }
}
