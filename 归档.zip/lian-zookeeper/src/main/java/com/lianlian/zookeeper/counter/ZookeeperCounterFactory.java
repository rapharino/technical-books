package com.lianlian.zookeeper.counter;

import com.lianlian.common.atomic.CachedCounterFactory;
import com.lianlian.common.atomic.Counter;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.atomic.DistributedAtomicLong;
import org.apache.curator.retry.RetryNTimes;
import org.apache.curator.retry.RetryUntilElapsed;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

/**
 * Created By Rapharino on 2020/9/7 7:50 下午
 */
public class ZookeeperCounterFactory extends CachedCounterFactory implements InitializingBean, DisposableBean {

    private final CuratorFramework curatorFramework;
    // default connection timeout
    private final static int DEFAULT_CONNECTION_TIMEOUT = 5_000;
    // default session timeout
    private final static int DEFAULT_SESSION_TIMEOUT = 5_000;
    // default DistributedAtomicLong retry time out
    private final static int DEFAULT_RETRY_TIMEOUT = 5_000;

    public ZookeeperCounterFactory(String zkUrl) {
        this(CuratorFrameworkFactory.builder()
                .sessionTimeoutMs(DEFAULT_SESSION_TIMEOUT)
                .retryPolicy(new RetryNTimes(3, 1000)) // default retry // 间隔1秒,重试最多3次.
                .connectionTimeoutMs(DEFAULT_CONNECTION_TIMEOUT)
                .connectString(zkUrl)
                .build());
    }

    public ZookeeperCounterFactory(CuratorFramework curatorFramework) {
        this.curatorFramework = curatorFramework;
    }

    private final static String ROOT = "/lian-counter/";

    @Override
    protected Counter create(String namespace, String name) {
        DistributedAtomicLong counter = new DistributedAtomicLong(this.curatorFramework,
                ROOT+namespace+"/" + name,
                new RetryUntilElapsed(DEFAULT_RETRY_TIMEOUT, 0));
        return new ZookeeperCounter(counter);
    }

    @Override
    public void destroy() throws Exception {
        this.curatorFramework.close();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(this.curatorFramework, "curator client is required");
        this.curatorFramework.start();
    }
}
